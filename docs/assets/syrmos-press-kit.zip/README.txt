SYRMOS - PRESS KIT
==================

Contents
--------

  BOILERPLATE.txt          Approved short description of Syrmos, in
                           plain text. Use verbatim or trim as needed.
  FACT-SHEET.txt           Product facts as an aligned table:
                           platforms, pricing, privacy, stack, links.

  icons/
    icon-default-1024.png  App icon, default variant, 1024 x 1024
    icon-dark-1024.png     App icon, iOS dark variant, 1024 x 1024
    icon-tinted-1024.png   App icon, iOS tinted variant, 1024 x 1024
    favicon-512.png        Favicon, 512 x 512

  screenshots/
    ios_home.png           Home screen, 1206 x 2622
    ios_map.png            Live train map, 1206 x 2622
    ios_lines.png          Lines browser, 1206 x 2622
    ios_settings.png       Settings, 1206 x 2622

Usage terms
-----------

You may reproduce these assets to write about, review, or link to
Syrmos, without needing to ask first. Please do not modify the app
icon or crop screenshots in a way that misrepresents the product.

Assets in this kit are released under CC BY-SA 4.0. Attribute
"Syrmos" and, where space allows, "by Petros Dhespollari".

Source code links live on the website. Syrmos itself is BSD 3-Clause
licensed and open source.

Trademarks
----------

Syrmos is not affiliated with STASY, OASA, or Hellenic Train. All
network names and logos remain the property of their respective
operators and are used only where required to describe the service.

Contact
-------

Petros Dhespollari, creator and maintainer
info@peterdsp.dev
Replies within a working day, in English or Greek.

Website:   https://syrmos.peterdsp.dev
Source:    https://github.com/peterdsp/Syrmos
Press page: https://syrmos.peterdsp.dev/press.html
